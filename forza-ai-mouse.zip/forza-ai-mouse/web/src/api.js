// Talks ONLY to the Android companion's local HTTP API. A website cannot control
// Android by itself; every action below is executed by the native app.
const KEY = 'forza.session';
export const loadSession = () => { try { return JSON.parse(localStorage.getItem(KEY)); } catch { return null; } };
export const saveSession = (s) => (s ? localStorage.setItem(KEY, JSON.stringify(s)) : localStorage.removeItem(KEY));

export async function call(session, method, path, body) {
  const res = await fetch(session.base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(session.token ? { Authorization: `Bearer ${session.token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(4000),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || res.statusText), { status: res.status });
  return data;
}
