import { useCallback, useEffect, useRef, useState } from 'react';
import { call, loadSession, saveSession } from './api.js';

const clamp = (v) => Math.min(1, Math.max(0, v));
const pct = (v) => Math.round(v * 100);

export default function App() {
  const [session, setSession] = useState(loadSession);
  const [online, setOnline] = useState(false);
  const [info, setInfo] = useState(null);
  const [toast, setToast] = useState('');
  const [tab, setTab] = useState('pad');
  const [cur, setCur] = useState({ x: 0.5, y: 0.5 });

  // Never throws; shows a plain-language message instead.
  const send = useCallback(async (method, path, body) => {
    try {
      const r = await call(session, method, path, body);
      setOnline(true);
      if (r.ok === false) setToast('The phone could not perform that action');
      return r;
    } catch (e) {
      if (e.status === 401) { saveSession(null); setSession(null); }
      else if (e.status === 403) { setOnline(true); setToast('Remote control is off. Allow it in the phone app.'); }
      else { setOnline(false); setToast('Phone unreachable. Check Wi-Fi and the address.'); }
      return null;
    }
  }, [session]);

  useEffect(() => {
    if (!session) return;
    let alive = true;
    const poll = async () => { const r = await send('GET', '/v1/status'); if (alive && r) setInfo(r); };
    poll();
    const id = setInterval(poll, 2500);
    return () => { alive = false; clearInterval(id); };
  }, [session, send]);

  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(''), 3000); return () => clearTimeout(t); }, [toast]);

  const emergencyStop = async () => {
    await send('POST', '/v1/stop');
    saveSession(null); setSession(null); setInfo(null); setOnline(false);
  };

  if (!session) return <Pair onPaired={setSession} />;

  const state = !online ? ['offline', 'Offline'] : info?.controlEnabled ? ['live', 'Control on'] : ['locked', 'Control off'];

  return (
    <div className="app">
      <header>
        <div>
          <h1>Forza AI Mouse</h1>
          <span className={`pill ${state[0]}`}>{state[1]}</span>
        </div>
        <button className="stop" onClick={emergencyStop}>Emergency stop</button>
      </header>

      <nav className="tabs">
        <button className={tab === 'pad' ? 'on' : ''} onClick={() => setTab('pad')}>Touchpad</button>
        <button className={tab === 'chat' ? 'on' : ''} onClick={() => setTab('chat')}>Assistant</button>
      </nav>

      {tab === 'pad'
        ? <Controls send={send} info={info} cur={cur} setCur={setCur} />
        : <Assistant send={send} onStop={emergencyStop} />}

      {toast && <div className="toast" role="status">{toast}</div>}
    </div>
  );
}

function Pair({ onPaired }) {
  const [base, setBase] = useState(location.protocol === 'http:' ? location.origin : 'http://192.168.');
  const [code, setCode] = useState('');
  const [name, setName] = useState('Forza Dashboard');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true); setErr('');
    const b = base.trim().replace(/\/+$/, '');
    try {
      const r = await call({ base: b }, 'POST', '/v1/pair', { code: code.trim(), deviceName: name });
      const s = { base: b, token: r.token };
      saveSession(s); onPaired(s);
    } catch (e) {
      setErr(e.status === 403 ? 'Wrong or expired code. Tap “Start pairing” on the phone for a new one.'
        : e.status === 429 ? 'Too many wrong codes. Wait 5 minutes.'
        : 'Cannot reach the phone. Check the address and that both devices are on the same Wi-Fi.');
    }
    setBusy(false);
  };

  return (
    <div className="app pair">
      <h1>Pair with your phone</h1>
      <ol>
        <li>Install the Forza AI Mouse app and enable its accessibility service.</li>
        <li>In the app, tap <b>Start pairing</b>. It shows an address and a 6-digit code.</li>
        <li>Enter both below.</li>
      </ol>
      <label>Phone address<input value={base} onChange={(e) => setBase(e.target.value)} inputMode="url" autoCapitalize="none" /></label>
      <label>6-digit code<input value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))} inputMode="numeric" className="code" /></label>
      <label>This dashboard’s name<input value={name} onChange={(e) => setName(e.target.value)} maxLength={40} /></label>
      {err && <p className="err">{err}</p>}
      <button className="primary" disabled={busy || code.length !== 6} onClick={submit}>{busy ? 'Pairing…' : 'Pair'}</button>
      <p className="hint">Pairing only grants a token. The phone still asks you to switch on Remote control before anything is executed.</p>
    </div>
  );
}

function Controls({ send, info, cur, setCur }) {
  const ref = useRef(null);
  const st = useRef(null);
  const [mode, setMode] = useState('point');
  const [text, setText] = useState('');

  const pos = (e) => {
    const r = ref.current.getBoundingClientRect();
    return { x: clamp((e.clientX - r.left) / r.width), y: clamp((e.clientY - r.top) / r.height) };
  };
  const down = (e) => { ref.current.setPointerCapture(e.pointerId); const p = pos(e); setCur(p); st.current = { p, t: Date.now(), moved: false }; };
  const move = (e) => {
    if (!st.current) return;
    const p = pos(e); setCur(p);
    if (Math.hypot(p.x - st.current.p.x, p.y - st.current.p.y) > 0.02) st.current.moved = true;
  };
  const up = (e) => {
    const s = st.current; st.current = null; if (!s) return;
    const p = pos(e), dt = Date.now() - s.t;
    if (mode === 'tap' && !s.moved) send('POST', dt >= 600 ? '/v1/longpress' : '/v1/tap', p);
    if (mode === 'swipe' && s.moved)
      send('POST', '/v1/swipe', { x1: s.p.x, y1: s.p.y, x2: p.x, y2: p.y, durationMs: Math.max(150, Math.min(dt, 1500)) });
  };

  const submitText = (e) => { e.preventDefault(); if (!text) return; send('POST', '/v1/text', { text }).then((r) => r && setText('')); };
  const ratio = info?.screen ? `${info.screen.w} / ${info.screen.h}` : '9 / 19.5';

  return (
    <main>
      <div className="modes">
        {[['point', 'Point'], ['tap', 'Touch'], ['swipe', 'Swipe / drag']].map(([k, l]) => (
          <button key={k} className={mode === k ? 'on' : ''} onClick={() => setMode(k)}>{l}</button>
        ))}
      </div>

      <div className="padwrap">
        <div ref={ref} className="pad" style={{ aspectRatio: ratio }}
          onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={() => (st.current = null)}>
          <span className="cursor" style={{ left: `${cur.x * 100}%`, top: `${cur.y * 100}%` }} />
          <span className="readout">x {pct(cur.x)}%  y {pct(cur.y)}%</span>
          <span className="phone-label">Phone screen</span>
        </div>

        <div className="side">
          <button onClick={() => send('POST', '/v1/tap', cur)}>Left click</button>
          <button onClick={() => send('POST', '/v1/longpress', cur)}>Right click<small>long press</small></button>
          <button onClick={() => send('POST', '/v1/scroll', { direction: 'up' })}>Scroll up</button>
          <button onClick={() => send('POST', '/v1/scroll', { direction: 'down' })}>Scroll down</button>
        </div>
      </div>

      <div className="nav3">
        <button onClick={() => send('POST', '/v1/action', { name: 'back' })}>Back</button>
        <button onClick={() => send('POST', '/v1/action', { name: 'home' })}>Home</button>
        <button onClick={() => send('POST', '/v1/action', { name: 'recents' })}>Recent apps</button>
      </div>

      <form className="textrow" onSubmit={submitText}>
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type into the focused field on the phone" />
        <button className="primary">Send text</button>
      </form>
    </main>
  );
}

// Local, rule-based command parser. A real LLM needs a backend (never put an API key in this page).
function parse(t) {
  const s = t.toLowerCase().trim(); let m;
  if (/\bstop\b/.test(s)) return { stop: true };
  if (/^type\s+/i.test(t)) return { path: '/v1/text', body: { text: t.replace(/^type\s+/i, '') }, say: 'Typing into the focused field.' };
  if (/\bback\b/.test(s)) return { path: '/v1/action', body: { name: 'back' }, say: 'Going back.' };
  if (/\bhome\b/.test(s)) return { path: '/v1/action', body: { name: 'home' }, say: 'Going home.' };
  if (/recent|overview/.test(s)) return { path: '/v1/action', body: { name: 'recents' }, say: 'Opening recent apps.' };
  if ((m = s.match(/scroll\s+(up|down)/))) return { path: '/v1/scroll', body: { direction: m[1] }, say: `Scrolling ${m[1]}.` };
  if ((m = s.match(/swipe\s+(left|right|up|down)/))) {
    const v = { left: [0.8, 0.5, 0.2, 0.5], right: [0.2, 0.5, 0.8, 0.5], up: [0.5, 0.75, 0.5, 0.25], down: [0.5, 0.25, 0.5, 0.75] }[m[1]];
    return { path: '/v1/swipe', body: { x1: v[0], y1: v[1], x2: v[2], y2: v[3], durationMs: 300 }, say: `Swiping ${m[1]}.` };
  }
  if (/long\s?press/.test(s)) return { path: '/v1/longpress', body: { x: 0.5, y: 0.5 }, say: 'Long-pressing the center of the screen.' };
  if (/\b(tap|click)\b/.test(s)) return { path: '/v1/tap', body: { x: 0.5, y: 0.5 }, say: 'Tapping the center of the screen.' };
  return null;
}

function Assistant({ send, onStop }) {
  const [msgs, setMsgs] = useState([{ from: 'ai', t: 'I can run simple commands: “go home”, “scroll down”, “swipe left”, “tap”, “type hello”, “stop”.' }]);
  const [v, setV] = useState('');
  const end = useRef(null);
  useEffect(() => end.current?.scrollIntoView({ block: 'end' }), [msgs]);

  const submit = async (e) => {
    e.preventDefault(); if (!v.trim()) return;
    const cmd = parse(v); const mine = { from: 'me', t: v }; setV('');
    if (!cmd) return setMsgs((m) => [...m, mine, { from: 'ai', t: 'I don’t know that command yet. Try “go home” or “scroll down”.' }]);
    if (cmd.stop) { setMsgs((m) => [...m, mine, { from: 'ai', t: 'Emergency stop sent. Control is off and the pairing is removed.' }]); return onStop(); }
    setMsgs((m) => [...m, mine, { from: 'ai', t: cmd.say }]);
    await send('POST', cmd.path, cmd.body);
  };

  return (
    <main className="chat">
      <p className="hint">Runs locally in this page using simple rules. Natural-language AI needs a separate backend service (not included).</p>
      <div className="log">{msgs.map((m, i) => <div key={i} className={`msg ${m.from}`}>{m.t}</div>)}<div ref={end} /></div>
      <form className="textrow" onSubmit={submit}>
        <input value={v} onChange={(e) => setV(e.target.value)} placeholder="Tell the phone what to do" />
        <button className="primary">Send</button>
      </form>
    </main>
  );
}
