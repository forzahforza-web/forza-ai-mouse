import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
// base './' so the build works when bundled into the Android app's assets/web
export default defineConfig({ base: './', plugins: [react()], server: { host: true } });
