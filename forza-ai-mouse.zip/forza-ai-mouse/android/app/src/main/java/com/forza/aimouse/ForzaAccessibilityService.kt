package com.forza.aimouse

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ForzaAccessibilityService : AccessibilityService() {

    companion object { @Volatile var instance: ForzaAccessibilityService? = null }

    private var server: ApiServer? = null

    override fun onServiceConnected() {
        instance = this
        ControlState.init(this)
        ControlState.controlEnabled = false // always start locked
        server = ApiServer(this, 8765).also { it.start(5000, false) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* intentionally ignored: no screen reading */ }
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        server?.stop(); server = null
        ControlState.emergencyStop()
        instance = null
        return super.onUnbind(intent)
    }

    fun screen(): Pair<Int, Int> = resources.displayMetrics.let { it.widthPixels to it.heightPixels }

    fun tap(x: Double, y: Double) = stroke(x, y, x, y, 60)
    fun longPress(x: Double, y: Double) = stroke(x, y, x, y, 700)
    fun swipe(x1: Double, y1: Double, x2: Double, y2: Double, ms: Long) = stroke(x1, y1, x2, y2, ms.coerceIn(100, 2000))

    /** "down" shows content further down the page (finger moves up). */
    fun scroll(dir: String) = when (dir) {
        "down" -> stroke(0.5, 0.7, 0.5, 0.3, 350)
        "up" -> stroke(0.5, 0.3, 0.5, 0.7, 350)
        else -> false
    }

    fun global(name: String) = when (name) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
        else -> false
    }

    /** Appends text to the focused input. Refuses password fields. */
    fun typeText(text: String): Boolean {
        val node = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (node.isPassword) return false
        val current = if (node.isShowingHintText) "" else node.text?.toString() ?: ""
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, current + text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun stroke(x1: Double, y1: Double, x2: Double, y2: Double, ms: Long): Boolean {
        if (listOf(x1, y1, x2, y2).any { it.isNaN() }) return false
        val (w, h) = screen()
        fun px(v: Double, max: Int) = (v.coerceIn(0.0, 1.0) * (max - 1)).toFloat()
        val path = Path().apply {
            moveTo(px(x1, w), px(y1, h))
            if (x1 != x2 || y1 != y2) lineTo(px(x2, w), px(y2, h))
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build()
        return dispatchGesture(g, null, null)
    }
}
