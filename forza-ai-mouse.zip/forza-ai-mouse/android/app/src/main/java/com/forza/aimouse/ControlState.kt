package com.forza.aimouse

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest
import java.security.SecureRandom

/** Single source of truth for authorization. Nothing executes unless this says so. */
object ControlState {
    /** Master switch. OFF by default on every service start; only the user can turn it ON in the app. */
    @Volatile var controlEnabled = false

    private var code: String? = null
    private var codeExpires = 0L
    private var failures = 0
    private var lockedUntil = 0L
    private lateinit var prefs: SharedPreferences

    fun init(c: Context) {
        if (!::prefs.isInitialized) prefs = c.applicationContext.getSharedPreferences("forza", Context.MODE_PRIVATE)
    }

    @Synchronized fun startPairing(): String {
        val c = "%06d".format(SecureRandom().nextInt(1_000_000))
        code = c; codeExpires = System.currentTimeMillis() + 120_000; failures = 0
        return c
    }

    @Synchronized fun pairingCode(): String? =
        if (code != null && System.currentTimeMillis() < codeExpires) code else null

    fun isLocked() = System.currentTimeMillis() < lockedUntil

    /** Returns a new token only if the user opened pairing in the app and the code matches. */
    @Synchronized fun pair(input: String, device: String): String? {
        val now = System.currentTimeMillis()
        if (isLocked()) return null
        val c = pairingCode()
        if (c == null || !MessageDigest.isEqual(c.toByteArray(), input.toByteArray())) {
            if (++failures >= 5) { lockedUntil = now + 300_000; code = null; failures = 0 }
            return null
        }
        code = null
        val token = ByteArray(32).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        prefs.edit().putString("token", token).putString("device", device).apply()
        return token
    }

    fun isValid(t: String?): Boolean {
        val saved = prefs.getString("token", null) ?: return false
        return t != null && MessageDigest.isEqual(saved.toByteArray(), t.toByteArray())
    }

    fun pairedDevice(): String? = prefs.getString("device", null)
    fun revoke() { prefs.edit().remove("token").remove("device").apply() }

    /** Emergency stop: disable control, close pairing, forget the paired dashboard. */
    @Synchronized fun emergencyStop() { controlEnabled = false; code = null; revoke() }
}
