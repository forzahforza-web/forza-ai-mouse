package com.forza.aimouse

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var info: TextView
    private lateinit var codeView: TextView
    private lateinit var sw: Switch
    private var updating = false
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 1000) } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(t: String, sp: Float = 14f, c: Int = 0xFFB8C2D9.toInt()) =
        TextView(this).apply { text = t; textSize = sp; setTextColor(c); setPadding(0, dp(6), 0, dp(6)) }
    private fun btn(t: String, bg: Int, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(bg); setOnClickListener { f() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        ControlState.init(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(28), dp(20), dp(28)) }
        val scroll = ScrollView(this).apply { setBackgroundColor(0xFF0B1020.toInt()); addView(col) }
        setContentView(scroll)

        col.addView(tv("Forza AI Mouse", 26f, Color.WHITE))
        col.addView(tv("Companion app. Nothing runs unless you allow it here.", 14f))

        col.addView(tv("1. Accessibility permission", 17f, Color.WHITE))
        col.addView(tv(
            "Open Accessibility settings, choose Installed apps (or Downloaded apps), tap Forza AI Mouse and switch it on.\n\n" +
            "Sideloaded APK on Android 13+: if the switch is greyed out, go to Settings > Apps > Forza AI Mouse > ⋮ > Allow restricted settings, then try again."))
        col.addView(btn("Open Accessibility settings", 0xFF2A3558.toInt()) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })

        col.addView(tv("2. Pair a dashboard", 17f, Color.WHITE))
        col.addView(btn("Start pairing (2 minutes)", 0xFF4F7BFF.toInt()) {
            if (ForzaAccessibilityService.instance == null) toast("Enable the accessibility service first")
            else codeView.text = ControlState.startPairing()
        })
        codeView = tv("—", 34f, Color.WHITE).apply { gravity = Gravity.CENTER }
        col.addView(codeView)
        info = tv("")
        col.addView(info)
        col.addView(btn("Unpair dashboard", 0xFF2A3558.toInt()) { ControlState.revoke(); refresh() })

        col.addView(tv("3. Allow remote control", 17f, Color.WHITE))
        sw = Switch(this).apply {
            text = "Remote control"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, on ->
                if (updating) return@setOnCheckedChangeListener
                if (!on) { ControlState.controlEnabled = false; return@setOnCheckedChangeListener }
                if (ForzaAccessibilityService.instance == null || ControlState.pairedDevice() == null) {
                    toast("Enable the service and pair a dashboard first"); refresh(); return@setOnCheckedChangeListener
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Allow remote control?")
                    .setMessage("“${ControlState.pairedDevice()}” will be able to tap, swipe, scroll, press Back/Home/Recents and type text on this phone until you switch this off.")
                    .setPositiveButton("Allow") { _, _ -> ControlState.controlEnabled = true; refresh() }
                    .setNegativeButton("Cancel") { _, _ -> refresh() }
                    .setOnCancelListener { refresh() }
                    .show()
            }
        }
        col.addView(sw)

        col.addView(btn("EMERGENCY STOP", 0xFFD7263D.toInt()) {
            ControlState.emergencyStop(); toast("Stopped. Control off, dashboard unpaired."); refresh()
        }.apply { textSize = 18f; setPadding(0, dp(18), 0, dp(18)) })

        col.addView(tv("Privacy: this app never reads, records or captures your screen, never types into password fields, and collects no passwords or financial data. Traffic stays on your local network.", 12f, 0xFF7F8AA6.toInt()))
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun refresh() {
        val on = ForzaAccessibilityService.instance != null
        info.text = "Service: ${if (on) "ON" else "OFF"}\n" +
            "Address: ${if (on) "http://${localIp()}:8765" else "—"}\n" +
            "Paired: ${ControlState.pairedDevice() ?: "none"}\n" +
            "Remote control: ${if (ControlState.controlEnabled) "ALLOWED" else "off"}"
        codeView.text = ControlState.pairingCode() ?: "—"
        updating = true; sw.isChecked = ControlState.controlEnabled; updating = false
    }

    private fun localIp(): String = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }?.hostAddress ?: "unknown"
    } catch (e: Exception) { "unknown" }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
