package com.forza.aimouse

import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject

class ApiServer(private val svc: ForzaAccessibilityService, port: Int) : NanoHTTPD(port) {

    private val tooMany = object : Response.IStatus {
        override fun getRequestStatus() = 429
        override fun getDescription() = "429 Too Many Requests"
    }

    private fun cors(r: Response): Response {
        r.addHeader("Access-Control-Allow-Origin", "*") // auth is a bearer token, not cookies
        r.addHeader("Access-Control-Allow-Headers", "Authorization, Content-Type")
        r.addHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        r.addHeader("Access-Control-Allow-Private-Network", "true")
        return r
    }

    private fun json(s: Response.IStatus, o: JSONObject) = cors(newFixedLengthResponse(s, "application/json", o.toString()))
    private fun err(s: Response.IStatus, code: String) = json(s, JSONObject().put("error", code))
    private val ok = Response.Status.OK

    override fun serve(s: IHTTPSession): Response {
        if (s.method == Method.OPTIONS) return cors(newFixedLengthResponse(Response.Status.NO_CONTENT, "text/plain", ""))
        val path = s.uri
        if (!path.startsWith("/v1/")) return asset(path)

        var body = JSONObject()
        if (s.method == Method.POST) {
            try {
                val m = HashMap<String, String>(); s.parseBody(m)
                m["postData"]?.takeIf { it.isNotBlank() }?.let { body = JSONObject(it) }
            } catch (e: Exception) { return err(Response.Status.BAD_REQUEST, "bad_json") }
        }

        // ---- unauthenticated ----
        if (path == "/v1/health")
            return json(ok, JSONObject().put("ok", true).put("app", "Forza AI Mouse").put("pairingOpen", ControlState.pairingCode() != null))
        if (path == "/v1/pair") {
            if (s.method != Method.POST) return err(Response.Status.METHOD_NOT_ALLOWED, "post_only")
            if (ControlState.isLocked()) return err(tooMany, "locked_try_later")
            val token = ControlState.pair(body.optString("code"), body.optString("deviceName", "Dashboard").take(40))
                ?: return err(Response.Status.FORBIDDEN, "bad_or_expired_code")
            return json(ok, JSONObject().put("token", token))
        }

        // ---- authenticated ----
        val tok = s.headers["authorization"]?.removePrefix("Bearer ")?.trim()
        if (!ControlState.isValid(tok)) return err(Response.Status.UNAUTHORIZED, "unauthorized")

        when (path) {
            "/v1/status" -> {
                val (w, h) = svc.screen()
                return json(ok, JSONObject().put("controlEnabled", ControlState.controlEnabled)
                    .put("device", ControlState.pairedDevice())
                    .put("screen", JSONObject().put("w", w).put("h", h)))
            }
            "/v1/stop" -> { ControlState.emergencyStop(); return json(ok, JSONObject().put("stopped", true)) }
            "/v1/unpair" -> { ControlState.revoke(); ControlState.controlEnabled = false; return json(ok, JSONObject().put("unpaired", true)) }
        }

        if (s.method != Method.POST) return err(Response.Status.NOT_FOUND, "not_found")
        if (!ControlState.controlEnabled) return err(Response.Status.FORBIDDEN, "control_disabled")

        fun d(k: String) = body.optDouble(k, Double.NaN)
        val done = when (path) {
            "/v1/tap" -> svc.tap(d("x"), d("y"))
            "/v1/longpress" -> svc.longPress(d("x"), d("y"))
            "/v1/swipe" -> svc.swipe(d("x1"), d("y1"), d("x2"), d("y2"), body.optLong("durationMs", 300))
            "/v1/scroll" -> svc.scroll(body.optString("direction"))
            "/v1/text" -> svc.typeText(body.optString("text").take(500))
            "/v1/action" -> svc.global(body.optString("name"))
            else -> return err(Response.Status.NOT_FOUND, "not_found")
        }
        return json(ok, JSONObject().put("ok", done))
    }

    /** Serves the bundled dashboard (assets/web) so the page and API share one http origin. */
    private fun asset(p: String): Response {
        val name = if (p == "/") "index.html" else p.trimStart('/')
        if (name.contains("..")) return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not found")
        return try {
            newChunkedResponse(Response.Status.OK, getMimeTypeForFile(name), svc.assets.open("web/$name"))
        } catch (e: Exception) {
            newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Dashboard not bundled. See README.")
        }
    }
}
