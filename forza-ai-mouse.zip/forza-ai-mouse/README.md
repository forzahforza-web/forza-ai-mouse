# Forza AI Mouse

Two separate apps:

- `web/` – React dashboard (touchpad, buttons, text, assistant, pairing screen).
- `android/` – Kotlin companion app (AccessibilityService + local authenticated HTTP API).

**A website cannot control Android apps.** The dashboard only sends HTTP requests; the native companion, after you pair and allow control, performs every action through Android's AccessibilityService. Not compiled or run on a device in the environment that produced this code: build and test it yourself using the steps below.

## What is native vs web

| Feature | Where it runs | Status |
|---|---|---|
| Touchpad, cursor position readout, click/scroll buttons, chat UI, pairing screen | Web | Done |
| Tap, long press, swipe/drag, scroll, Back/Home/Recents, text entry | Android (AccessibilityService) | Done |
| Pairing, tokens, local HTTP API, emergency stop | Android | Done |
| Cursor drawn **on the phone screen** | Android overlay (`SYSTEM_ALERT_WINDOW`) | **Not implemented**. Cursor shows on the dashboard only |
| Real right-click | Android has no mouse right-click | Mapped to long press |
| Live screen mirroring | Android `MediaProjection` with per-session consent | **Not implemented** (nothing captures the screen) |
| Natural-language AI assistant | Needs a backend + LLM API | **Not implemented**. Chat uses local keyword rules |
| HTTPS/TLS on the local link | Android | **Not implemented**. Traffic is plain HTTP on your LAN |
| Quick Settings tile / hardware-key stop | Android | **Not implemented** (in-app and dashboard stop only) |

## Security model

1. Pairing needs a 6-digit code generated **on the phone** when you tap *Start pairing* (valid 2 min, single use). 5 wrong tries lock pairing for 5 min.
2. Pairing returns a random 256-bit bearer token. Every other endpoint requires `Authorization: Bearer <token>`.
3. A second gate, **Remote control**, is OFF at every service start. Turning it on shows a confirmation dialog. Without it, action endpoints return `403 control_disabled`.
4. **Emergency stop** (app button, dashboard button, or `POST /v1/stop`) turns control off, closes pairing and deletes the token.
5. Never types into password fields. No screen capture or screen reading. No passwords or financial data are collected.
6. The service config requests `canRetrieveWindowContent` only to find the focused text field; the code never reads or sends screen content.
7. Limits: the token sits in app-private SharedPreferences; the link is unencrypted HTTP, so use trusted Wi-Fi only. Android restricted settings and OS gesture/secure-window rules are respected, not bypassed (e.g. gestures can't touch some secure system dialogs).

## API (base `http://<phone-ip>:8765`)

Coordinates are fractions of the screen, `0.0`–`1.0`. JSON in/out. CORS is enabled.

| Method & path | Auth | Body | Response |
|---|---|---|---|
| `GET /v1/health` | none | – | `{ok, app, pairingOpen}` |
| `POST /v1/pair` | none | `{code, deviceName}` | `{token}`; `403 bad_or_expired_code`; `429 locked_try_later` |
| `GET /v1/status` | token | – | `{controlEnabled, device, screen:{w,h}}` |
| `POST /v1/tap` | token + control | `{x,y}` | `{ok}` |
| `POST /v1/longpress` | token + control | `{x,y}` | `{ok}` |
| `POST /v1/swipe` | token + control | `{x1,y1,x2,y2,durationMs}` (100–2000) | `{ok}` |
| `POST /v1/scroll` | token + control | `{direction:"up"\|"down"}` | `{ok}` |
| `POST /v1/text` | token + control | `{text}` (max 500) appended to focused field | `{ok}` (false if no field / password field) |
| `POST /v1/action` | token + control | `{name:"back"\|"home"\|"recents"}` | `{ok}` |
| `POST /v1/stop` | token | – | `{stopped:true}` |
| `POST /v1/unpair` | token | – | `{unpaired:true}` |

Errors: `401 unauthorized`, `403 control_disabled`, `400 bad_json`, `404 not_found`. `{"ok":false}` means Android refused the action.

```bash
TOKEN=$(curl -s -X POST http://PHONE:8765/v1/pair -H 'Content-Type: application/json' -d '{"code":"123456","deviceName":"curl"}' | sed 's/.*"token":"\([^"]*\)".*/\1/')
curl -X POST http://PHONE:8765/v1/action -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"name":"home"}'
```

## Install and run

### 1. Android app
1. Install Android Studio (Koala or newer, JDK 17). Open `android/`; let it sync (it creates the Gradle wrapper).
2. Plug in your Samsung phone (Developer options + USB debugging) and press Run.
3. On the phone, open **Forza AI Mouse** and follow the on-screen steps. Samsung path: Settings > Accessibility > Installed apps > Forza AI Mouse > On. If greyed out (sideloaded APK, Android 13+): Settings > Apps > Forza AI Mouse > ⋮ > **Allow restricted settings**, then retry.

### 2. Dashboard
```bash
cd web
npm install
npm run dev        # http://<computer-ip>:5173 (Chrome on a PC or another phone)
```
Mixed-content note: an `https://` page cannot call `http://192.168.x.x`. Use the dev server (http), or bundle the dashboard into the phone app (below) and open `http://<phone-ip>:8765` in Chrome.

Bundle into the app (optional):
```bash
npm run build && rm -rf ../android/app/src/main/assets/web && cp -r dist ../android/app/src/main/assets/web
```

### 3. Test checklist
1. Phone and controller on the same Wi-Fi. App shows *Service ON* and an address.
2. Tap **Start pairing**; enter address + code on the dashboard. Expect the touchpad screen, pill "Control off".
3. Press Home on the dashboard: nothing happens, toast says control is off. (Correct.)
4. On the phone switch **Remote control** on and confirm. Pill turns "Control on".
5. Test Home, Back, Recent apps, Scroll in a browser page, Touch mode tap on an icon, Swipe mode drag, then focus a search box and use Send text. Password fields must refuse.
6. Press **Emergency stop**: dashboard returns to pairing; phone shows control off and *Paired: none*.
7. Wrong code 5 times: expect `429`.

## Build an APK
- Debug: `cd android && gradle wrapper && ./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk` (copy to the phone and open it; allow "install unknown apps").
- Release: Android Studio > Build > Generate Signed Bundle / APK > APK, create a keystore, choose `release`. Or `./gradlew assembleRelease` with a `signingConfigs` block. Keep the keystore private.
- Google Play restricts AccessibilityService apps; publishing needs a declaration and policy review. Sideloading is the simplest path.
